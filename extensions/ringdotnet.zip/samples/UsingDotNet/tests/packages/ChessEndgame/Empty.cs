class Empty { }
