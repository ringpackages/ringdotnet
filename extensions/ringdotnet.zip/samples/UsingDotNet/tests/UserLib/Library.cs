using System;
using System.Collections.Generic;

namespace MyCompany.Tools
{
	public enum Level { Low, Medium, High }

	public class Calculator
	{
		public double Total { get; private set; }
		public string Name { get; set; } = "calc";
		public event EventHandler Changed;

		public Calculator() { }
		public Calculator(double start) { Total = start; }

		public Calculator Add(double value) { Total += value; Changed?.Invoke(this, EventArgs.Empty); return this; }
		public Calculator Multiply(double value) { Total *= value; return this; }
		public static int Square(int x) { return x * x; }
		public static string EnumName(Enum value) { return value.GetType().Name + "." + value; }
		public string Describe(Level level, string prefix = "Total") { return prefix + "=" + Total + " (" + level + ")"; }
		public bool TryDivide(double by, out double result)
		{
			result = 0;
			if (by == 0) return false;
			result = Total / by;
			return true;
		}
		public List<string> Words(string text) { return new List<string>(text.Split(' ')); }
	}

	public class Counter : Calculator
	{
		public int Count { get; set; }
		public void Increment() { Count++; }
	}
	// An interface that inherits another one, and a class that is not public: Shapes.NewBox returns the interface IBox.
	// The wrapper must be IBox (the interface named after the class), with the members that IBox inherits from IShape.
	public interface IShape
	{
		string Name { get; set; }
		double Area();
	}

	public interface IBox : IShape
	{
		double Side { get; }
	}

	internal class Box : IShape, IBox
	{
		public string Name { get; set; } = "box";
		public double Side { get; private set; }
		public Box(double side) { Side = side; }
		public double Area() { return Side * Side; }
	}

	public static class Shapes
	{
		public static IBox NewBox(double side) { return new Box(side); }
	}
	// A class that is not public and implements a public interface explicitly (a row of Dapper is like this): the methods of the interface
	// are called on the object although the class has no public method of that name.
	public interface IGetter
	{
		string Fetch(string key);
		string Join(string first, string second);
		string Join(string only);
	}

	internal class Hidden : IGetter
	{
		string IGetter.Fetch(string key) { return key + "!"; }
		string IGetter.Join(string first, string second) { return first + "+" + second; }
		string IGetter.Join(string only) { return only; }
	}

	public static class Hiding
	{
		public static object NewGetter() { return new Hidden(); }
	}
	// A class with the name of a class of the library (System.Version): the generator gives it the prefix of its namespace, ToolsVersion,
	// so that both can be defined in one program.
	public class Version
	{
		public string Text { get { return "user version"; } }
	}
	// Extension methods are methods of the Ring class of the type that they extend: calc.Shout("!") is CalculatorExtensions.Shout(calc, "!").
	// Describe has the same name and the same number of parameters as a method of Calculator (the compiler chooses by the type of the value);
	// Add has more parameters than the method of Calculator, so it is not added (an extension never changes the signature of a method).
	public static class CalculatorExtensions
	{
		public static string Shout(this Calculator calc, string suffix) { return calc.Name.ToUpper() + suffix; }
		public static string Describe(this Calculator calc, string format) { return string.Format(format, calc.Total); }
		public static string Add(this Calculator calc, string first, string second) { return first + second; }
	}
}
