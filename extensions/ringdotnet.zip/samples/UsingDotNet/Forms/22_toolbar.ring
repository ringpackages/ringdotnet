# A tool strip with buttons

load "dotnet.ring"

using {
	"System.Drawing"
	"System.Windows.Forms"
}

oForm = uiForm("Toolbar",360,160)
oBar = new ToolStrip()
for cName in ["New","Open","Save"]
	oTool = new ToolStripButton() {
		Text = cName
		setClickEvent("oStatus.Text = 'Clicked ' + '" + cName + "'")
	}
	oBar.Items.Add(oTool)
next
oForm.Controls.Add(oBar)
oStatus = uiLabel(oForm,"",15,50,320,24)

uiRun(oForm)
