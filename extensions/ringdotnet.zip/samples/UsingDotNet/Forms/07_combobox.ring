# A drop-down list

load "dotnet.ring"
using {
	"System.Drawing"
	"System.Windows.Forms"
}

oForm = uiForm("Combo box",300,130)
oCombo = uiComboBox(oForm,20,20,160,["Ring","Python","Lua","C"])
oChoice = uiLabel(oForm,"",20,65,260,24)
oCombo.setSelectedIndexChangedEvent("oChoice.Text = 'Language: ' + oCombo.Text")

uiRun(oForm)
