# The smallest window: a form with a label

load "dotnet.ring"
using {
	"System.Drawing"
	"System.Windows.Forms"
}

oForm = uiForm("Hello",300,120)
oLabel = uiLabel(oForm,"Hello from Ring and .NET!",20,40,260,30)
oLabel.Font = uiFont("Segoe UI",14,true)

uiRun(oForm)
