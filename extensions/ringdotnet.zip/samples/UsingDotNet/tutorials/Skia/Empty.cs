// A project needs one source file to build; the program only wants the package that the project refers to.
namespace Tutorial.Skia { class Empty { } }
