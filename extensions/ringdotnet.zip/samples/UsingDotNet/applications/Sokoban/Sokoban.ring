# Sokoban - push every box onto a target with the arrow keys (a port of ring/applications/sokoban, with its pictures: the folder images)
#   # wall   @ player   $ box   . target   * box on a target   + player on a target

load "dotnet.ring"

using {
	"System.Drawing"
	"System.Windows.Forms"
}

C_CELL = 33		# the size of the pictures in the folder images

aLevels = [
	["#######",
	 "#.@ $ #",
	 "#     #",
	 "#######"],
	["########",
	 "#      #",
	 "# .$.$ #",
	 "#  @   #",
	 "########"],
	["  #####",
	 "###   #",
	 "#.@$  #",
	 "### $.#",
	 "#.##$ #",
	 "# # . ##",
	 "#$ *$$.#",
	 "#   .  #",
	 "########"]
]
nLevel = 1
aMap = []		# list of strings
nPlayerColumn = 0
nPlayerRow = 0
nMoves = 0
aImages = []		# [tile, picture] for every kind of square: loaded once

loadImages()
oForm = uiForm("Sokoban",400,300)
oForm {
	KeyPreview = True
	FormBorderStyle = "FixedSingle"
	MaximizeBox = False
}
oPicture = uiPictureBox(oForm,0,36,400,264)
oCanvas = new UiCanvas(oPicture)
oInfo = uiLabel(oForm,"",10,8,250,22)
oInfo.Font = uiFont("Segoe UI",11,true)
oRestart = uiButton(oForm,"Restart",270,5,60,26,"loadLevel(nLevel)")
oNext = uiButton(oForm,"Next",335,5,55,26,"nextLevel()")
uiGameKeys(oForm,"keyPressed(aDotNetArgs[2].KeyCode)")
loadLevel(1)

uiRun(oForm)

# --------------------------------------------------------------------------

# the pictures are in the folder images next to the program
func loadImages

	cFolder = ""
	if len(sysargv) > 1
		cScript = substr(sysargv[2],"\\","/")
		for nPos = len(cScript) to 1 step -1
			if cScript[nPos] = "/"
				cFolder = left(cScript,nPos)
				exit
			ok
		next
	ok
	aImages = []
	for aTile in [[" ","empty"],["#","wall"],["@","player"],["+","player"],[".","door"],["$","box"],["*","boxondoor"]]
		aImages + [aTile[1],new Bitmap(cFolder + "images/" + aTile[2] + ".jpg",0)]
	next

func imageOf cTile

	return aImages[find(aImages,cTile,1)][2]

func loadLevel nNumber

	nLevel = nNumber
	aMap = []
	for cRow in aLevels[nLevel]
		aMap + cRow
	next
	nMoves = 0
	fitWindow()
	for nRow = 1 to len(aMap)
		for nColumn = 1 to len(aMap[nRow])
			if aMap[nRow][nColumn] = "@" or aMap[nRow][nColumn] = "+"
				nPlayerColumn = nColumn
				nPlayerRow = nRow
			ok
		next
	next
	draw()

# the window and the picture follow the size of the level
func fitWindow

	nColumns = 0
	for cRow in aMap
		if len(cRow) > nColumns
			nColumns = len(cRow)
		ok
	next
	nWidth = nColumns * C_CELL
	if nWidth < 400
		nWidth = 400
	ok
	nHeight = len(aMap) * C_CELL
	oPicture.Size = new Size(nWidth,nHeight)
	oForm.ClientSize = new Size(nWidth,nHeight + 36)
	oCanvas = new UiCanvas(oPicture)
	oRestart.Left = nWidth - 130
	oNext.Left = nWidth - 65

func nextLevel

	loadLevel(nLevel % len(aLevels) + 1)

func tileAt nColumn, nRow

	if nRow < 1 or nRow > len(aMap) or nColumn < 1 or nColumn > len(aMap[nRow])
		return "#"
	ok
	return aMap[nRow][nColumn]

func setTile nColumn, nRow, cTile

	aMap[nRow][nColumn] = cTile

func isTarget cTile

	return cTile = "." or cTile = "*" or cTile = "+"

func isBox cTile

	return cTile = "$" or cTile = "*"

# the tile left behind: a target stays a target
func without cTile

	if isTarget(cTile)
		return "."
	ok
	return " "

func move nDx, nDy

	nTargetColumn = nPlayerColumn + nDx
	nTargetRow = nPlayerRow + nDy
	cTarget = tileAt(nTargetColumn,nTargetRow)
	if cTarget = "#"
		return false
	but isBox(cTarget)
		cBeyond = tileAt(nTargetColumn + nDx,nTargetRow + nDy)
		if cBeyond = "#" or isBox(cBeyond)
			return false
		ok
		# push the box
		if isTarget(cBeyond)
			setTile(nTargetColumn + nDx,nTargetRow + nDy,"*")
		else
			setTile(nTargetColumn + nDx,nTargetRow + nDy,"$")
		ok
	ok
	# move the player
	cHere = tileAt(nPlayerColumn,nPlayerRow)
	setTile(nPlayerColumn,nPlayerRow,without(cHere))
	if isTarget(cTarget)
		setTile(nTargetColumn,nTargetRow,"+")
	else
		setTile(nTargetColumn,nTargetRow,"@")
	ok
	nPlayerColumn = nTargetColumn
	nPlayerRow = nTargetRow
	nMoves++
	return true

func boxesLeft

	nCount = 0
	for cRow in aMap
		for x = 1 to len(cRow)
			if cRow[x] = "$"
				nCount++
			ok
		next
	next
	return nCount

func keyPressed cKey

	switch cKey
	on "Left"	move(-1,0)
	on "Right"	move(1,0)
	on "Up"		move(0,-1)
	on "Down"	move(0,1)
	off
	draw()

func draw

	oCanvas.clear("#222222")
	for nRow = 1 to len(aMap)
		for nColumn = 1 to len(aMap[nRow])
			oCanvas.oGraphics.DrawImage([ :image = imageOf(aMap[nRow][nColumn]), :x = (nColumn - 1) * C_CELL, :y = (nRow - 1) * C_CELL, :width = C_CELL, :height = C_CELL ])
		next
	next
	if boxesLeft() = 0
		oInfo.Text = "Level " + nLevel + " solved in " + nMoves + " moves!"
	else
		oInfo.Text = "Level " + nLevel + "   moves " + nMoves
	ok
	oCanvas.show()
