# To-do list with check boxes, saved to a text file

load "dotnet.ring"

using {
	"System"
	"System.IO"
	"System.Drawing"
	"System.Windows.Forms"
}

cFile = new Path().Combine([new Path().GetTempPath(),"ringdotnet_todo.txt"])
if uiSelfTest()
	cFile = new Path().Combine([new Path().GetTempPath(),"ringdotnet_todo_selftest.txt"])
ok

oForm = uiForm("To-do list",360,420)
oInput = uiTextBox(oForm,10,10,250,26)
uiButton(oForm,"Add",268,9,80,28,"addTask()")
oList = new CheckedListBox() {
	Location = new Point(10,46)
	Size = new Size(338,290)
	CheckOnClick = True
}
# ItemCheck fires before the state changes, so the counters are refreshed after the mouse or key press
oList {
	setMouseUpEvent("updateInfo()")
	setKeyUpEvent("updateInfo()")
}
oForm.Controls.Add(oList)
uiButton(oForm,"Remove checked",10,345,120,28,"removeDone()")
uiButton(oForm,"Save",140,345,80,28,"saveTasks()")
oInfo = uiLabel(oForm,"",10,382,338,22)
oForm.AcceptButton = oForm.Controls.Item(1)
loadTasks()

uiRun(oForm)

# --------------------------------------------------------------------------

func updateInfo

	nDone = oList.CheckedItems.Count
	oInfo.Text = string(oList.Items.Count) + " tasks, " + nDone + " done"

func addTask

	cTask = trim(oInput.Text)
	if cTask != ""
		oList.Items.Add([ :item = cTask, :isChecked = False ])
		oInput.Text = ""
		updateInfo()
	ok

func removeDone

	for nIndex = oList.Items.Count - 1 to 0 step -1
		if oList.GetItemChecked(nIndex)
			oList.Items.RemoveAt(nIndex)
		ok
	next
	updateInfo()

# one line per task: "[x] text" or "[ ] text"
func saveTasks

	cText = ""
	for nIndex = 0 to oList.Items.Count - 1
		if oList.GetItemChecked(nIndex)
			cText += "[x] "
		else
			cText += "[ ] "
		ok
		cText += oList.Items.Item(nIndex) + nl
	next
	new File().WriteAllText([ :path = cFile, :contents = cText ])

func loadTasks

	oList.Items.Clear()
	if new File().Exists(cFile)
		aLines = str2list(new File().ReadAllText(cFile))
		for cLine in aLines
			cLine = trim(cLine)
			if len(cLine) > 4
				oList.Items.Add([ :item = substr(cLine,5), :isChecked = (left(cLine,3) = "[x]") ])
			ok
		next
	ok
	updateInfo()
